STARZSMP CUSTOM STORE WEBSITE

How to use:
1. Open index.html to preview the website.
2. Edit script.js.
3. Replace YOURPAYPAL links with your real PayPal/Stripe checkout links.
4. Upload the folder to Netlify, GitHub Pages, or any web host.
5. When someone buys, manually give the rank with LuckPerms:
   lp user PLAYERNAME parent add RANK

Example:
lp user Steve parent add nova

Files:
- index.html = website page
- style.css = design/colors
- script.js = rank packages and checkout links
