const ranks = [
  {
    name: "⭐ Nova",
    price: "$4.99",
    link: "https://paypal.me/YOURPAYPAL/4.99",
    perks: ["/hat", "5 Homes", "2 Auction Slots", "Nova Kit", "Colored Chat"]
  },
  {
    name: "🌠 Supernova",
    price: "$9.99",
    link: "https://paypal.me/YOURPAYPAL/9.99",
    perks: ["Everything in Nova", "/craft", "8 Homes", "4 Auction Slots", "Supernova Kit"]
  },
  {
    name: "🌌 Nebula",
    price: "$19.99",
    link: "https://paypal.me/YOURPAYPAL/19.99",
    perks: ["Everything in Supernova", "/ec", "12 Homes", "6 Auction Slots", "1.3x Sell Multiplier"]
  },
  {
    name: "☄️ Pulsar",
    price: "$34.99",
    link: "https://paypal.me/YOURPAYPAL/34.99",
    perks: ["Everything in Nebula", "/feed", "15 Homes", "8 Auction Slots", "Pulsar Kit"]
  },
  {
    name: "🌟 Quasar",
    price: "$49.99",
    link: "https://paypal.me/YOURPAYPAL/49.99",
    perks: ["Everything in Pulsar", "/workbench", "20 Homes", "10 Auction Slots", "1.5x Sell Multiplier"]
  },
  {
    name: "👑 Celestial",
    price: "$79.99",
    link: "https://paypal.me/YOURPAYPAL/79.99",
    featured: true,
    perks: ["Everything in Quasar", "/fly", "Priority Queue", "Celestial Kit", "1.75x Sell Multiplier"]
  }
];

let selectedRank = null;

const grid = document.getElementById("rankGrid");

ranks.forEach((rank, index) => {
  const card = document.createElement("div");
  card.className = "card" + (rank.featured ? " featured" : "");
  card.innerHTML = `
    <h3>${rank.name}</h3>
    <div class="price">${rank.price}</div>
    <ul>${rank.perks.map(perk => `<li>${perk}</li>`).join("")}</ul>
    <button class="buy-btn" onclick="openModal(${index})">Buy Now</button>
  `;
  grid.appendChild(card);
});

function openModal(index) {
  selectedRank = ranks[index];
  document.getElementById("modalRank").textContent = `Buy ${selectedRank.name}`;
  document.getElementById("buyModal").style.display = "grid";
}

function closeModal() {
  document.getElementById("buyModal").style.display = "none";
}

function checkout() {
  const username = document.getElementById("mcName").value.trim();

  if (!username) {
    alert("Please enter your Minecraft username.");
    return;
  }

  // This opens your payment link.
  // You can check the PayPal note or message from the buyer for their Minecraft username.
  window.open(selectedRank.link + "?message=Minecraft Username: " + encodeURIComponent(username), "_blank");
}
